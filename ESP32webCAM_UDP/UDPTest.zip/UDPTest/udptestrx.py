import socket
import time

#UDP_IP = "127.0.0.1" 
UDP_IP = "192.168.178.20"
UDP_PORT = 5005

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(('', UDP_PORT))

while True:
    data, addr = sock.recvfrom(16) 
    print(bytes(data).hex())   
    #print("received message: %s" % data)
    #print(sock.recv(16))
