import socket
import time

#UDP_IP = "127.0.0.1"
UDP_IP = "192.168.178.45"
UDP_PORT = 4210
MESSAGE = b'\x55\x00\x01\x00\x02\x00\x03\x00\x04\x00\x05\x00\x06\x00'

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

while True:
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    print("sent")
    time.sleep(2)
